import time
from typing import Dict, Optional, Tuple
from dataclasses import dataclass, field

from config import CONFIG
from data_fetcher import DataFetcher
from bias_engine import decide_symbol
from dashboard import render
from logger import get_logger
from telegram_alerts import send_telegram_message

logger = get_logger()


@dataclass
class AlertRecord:
    """Track alert history for deduplication."""
    symbol: str
    bias: str
    probability: int
    timestamp: float
    count: int = 1  # How many times this alert fired


class AlertTracker:
    """
    IMPROVEMENT: Smart alert deduplication system.
    Only triggers new alerts when:
    1. Setup is new (different symbol/bias)
    2. Probability changed significantly (3%+)
    3. Time window passed (5+ minutes)
    """
    
    def __init__(self, min_time_between_alerts: int = 300, min_prob_change: int = 3):
        self.alerts: Dict[str, AlertRecord] = {}  # key: "BTC/USDT-LONG" -> AlertRecord
        self.min_time_between_alerts = min_time_between_alerts
        self.min_prob_change = min_prob_change
    
    def should_alert(self, symbol: str, bias: str, probability: int) -> bool:
        """
        Determine if we should send an alert.
        
        Returns True if:
        - This is a new setup (never seen before)
        - Probability improved significantly (3%+)
        - Minimum time window passed since last alert
        """
        key = f"{symbol}-{bias}"
        now = time.time()
        
        # New setup
        if key not in self.alerts:
            self.alerts[key] = AlertRecord(
                symbol=symbol,
                bias=bias,
                probability=probability,
                timestamp=now,
                count=1
            )
            logger.info(f"Alert tracking initialized: {key} @ {probability}%")
            return True
        
        record = self.alerts[key]
        time_elapsed = now - record.timestamp
        prob_change = abs(probability - record.probability)
        
        # Check conditions for new alert
        can_alert = (
            time_elapsed >= self.min_time_between_alerts and  # Minimum time passed
            prob_change >= self.min_prob_change  # Probability changed enough
        )
        
        if can_alert:
            logger.info(f"Alert triggered: {key} probability {record.probability}% -> {probability}% (elapsed {time_elapsed:.0f}s, change {prob_change}%)")
            record.probability = probability
            record.timestamp = now
            record.count += 1
            return True
        else:
            logger.debug(f"Alert suppressed: {key} (time_elapsed={time_elapsed:.0f}s, prob_change={prob_change}%)")
            return False
    
    def clear_stale_alerts(self, max_age: int = 3600):
        """
        Remove alerts older than max_age seconds.
        Call this periodically to clean up.
        """
        now = time.time()
        stale_keys = [
            key for key, record in self.alerts.items()
            if (now - record.timestamp) > max_age
        ]
        for key in stale_keys:
            logger.info(f"Clearing stale alert: {key}")
            del self.alerts[key]
    
    def get_alert_summary(self) -> str:
        """Get summary of tracked alerts."""
        if not self.alerts:
            return "No active alerts being tracked."
        
        lines = [f"Tracking {len(self.alerts)} active alert(s):"]
        for key, record in self.alerts.items():
            age = time.time() - record.timestamp
            lines.append(f"  {key}: {record.probability}% (sent {record.count}x, {age:.0f}s ago)")
        return "\n".join(lines)


class LiveUpdateEngine:
    def __init__(self):
        self.fetcher = DataFetcher()
        self.alert_tracker = AlertTracker(
            min_time_between_alerts=300,  # 5 minutes
            min_prob_change=3  # 3% probability change
        )
        self.cycle_count = 0

    def analyze_once(self):
        """Analyze all symbols and return decisions."""
        market_data = self.fetcher.fetch_all()
        decisions = {}

        for symbol, tf_data in market_data.items():
            decisions[symbol] = decide_symbol(symbol, tf_data)

        return decisions

    def maybe_alert(self, decisions: Dict) -> Optional[Tuple[str, str, int]]:
        """
        Find best setup and send alert if criteria met.
        
        IMPROVEMENT: Uses AlertTracker for smart deduplication.
        """
        # Find best active setup
        best = None
        for d in decisions.values():
            if d.bias in {"LONG", "SHORT"}:
                if best is None or d.probability > best.probability:
                    best = d

        if not best:
            return None
        
        # Check if we should send alert
        if self.alert_tracker.should_alert(best.symbol, best.bias, best.probability):
            msg = f"🚨 {best.symbol} {best.bias} | {best.probability}% | Quality: {best.quality} | Lev: {best.suggested_leverage}x"
            send_telegram_message(msg)
            logger.info(f"📤 Telegram alert sent: {msg}")
            return (best.symbol, best.bias, best.probability)
        
        return None

    def run_forever(self):
        """Main loop - analyze and render every update_interval_seconds."""
        logger.info("=" * 80)
        logger.info("Starting live crypto AI trading assistant (IMPROVED VERSION)")
        logger.info("Alert tracking: Min 5min between alerts, 3%+ probability change")
        logger.info("=" * 80)

        last_stale_clear = time.time()

        while True:
            try:
                self.cycle_count += 1
                logger.info(f"\n{'='*80}")
                logger.info(f"Analysis cycle #{self.cycle_count} at {time.strftime('%Y-%m-%d %H:%M:%S')}")
                logger.info(f"{'='*80}")
                
                # Run analysis
                decisions = self.analyze_once()
                
                # Render dashboard
                render(decisions)
                
                # Try to send alert
                alert_result = self.maybe_alert(decisions)
                if alert_result:
                    symbol, bias, prob = alert_result
                    logger.info(f"✓ Alert sent for {symbol} {bias} @ {prob}%")
                
                # Periodic cleanup of stale alerts (every 1 hour)
                now = time.time()
                if (now - last_stale_clear) > 3600:
                    self.alert_tracker.clear_stale_alerts(max_age=3600)
                    last_stale_clear = now
                
                # Log alert tracking summary every 10 cycles
                if self.cycle_count % 10 == 0:
                    logger.info(self.alert_tracker.get_alert_summary())
                
                logger.info(f"Analysis completed. Next update in {CONFIG.update_interval_seconds}s")

            except KeyboardInterrupt:
                logger.info("=" * 80)
                logger.info("Bot stopped by user.")
                logger.info(self.alert_tracker.get_alert_summary())
                logger.info("=" * 80)
                break
            except Exception as exc:
                logger.exception(f"❌ Live update failed: {exc}")

            time.sleep(CONFIG.update_interval_seconds)
