from dataclasses import dataclass
import pandas as pd


@dataclass
class StructureSignal:
    trend: str
    structure: str
    bos: str
    choch: str
    score: int


def _pivot_highs_lows(df: pd.DataFrame, lookback: int = 3):
    """
    IMPROVEMENT: Better pivot detection with volume confirmation and float safety.
    """
    highs, lows = [], []
    
    # Calculate volume average for confirmation
    vol_avg = float(df["volume"].rolling(20).mean().iloc[-1]) if len(df) >= 20 else float(df["volume"].mean())
    
    for i in range(lookback, len(df) - lookback):
        h = df["high"].iloc[i]
        l = df["low"].iloc[i]
        v = df["volume"].iloc[i]
        
        # Use >= instead of == for float safety
        # Check if this is a local high
        high_window = df["high"].iloc[i-lookback:i+lookback+1]
        if float(h) >= float(high_window.max()) * 0.999:  # 99.9% to account for float precision
            # IMPROVEMENT: Optional volume confirmation for significance
            if float(v) >= vol_avg * 0.8:  # Not requiring massive volume, but should be reasonable
                highs.append((i, float(h)))
        
        # Check if this is a local low
        low_window = df["low"].iloc[i-lookback:i+lookback+1]
        if float(l) <= float(low_window.min()) * 1.001:  # 100.1% to account for float precision
            # IMPROVEMENT: Optional volume confirmation for significance
            if float(v) >= vol_avg * 0.8:
                lows.append((i, float(l)))
    
    # Return last 10 instead of 5 for better structure analysis
    return highs[-10:], lows[-10:]


def analyze_structure(df: pd.DataFrame) -> StructureSignal:
    """
    IMPROVEMENT: Better structure analysis with volume-confirmed support/resistance.
    """
    highs, lows = _pivot_highs_lows(df)
    last_close = float(df["close"].iloc[-1])
    last_vol = float(df["volume"].iloc[-1])
    vol_avg = float(df["volume"].rolling(20).mean().iloc[-1]) if len(df) >= 20 else float(df["volume"].mean())

    trend = "Neutral"
    structure = "Mixed / unclear"
    score = 0

    # IMPROVEMENT: Better HH/HL, LH/LL detection with at least 3 pivots
    if len(highs) >= 3 and len(lows) >= 3:
        hh_count = 0
        hl_count = 0
        lh_count = 0
        ll_count = 0
        
        # Check last 3 pivots for consistency
        for i in range(len(highs) - 3, len(highs) - 1):
            if highs[i+1][1] > highs[i][1]:
                hh_count += 1
        
        for i in range(len(lows) - 3, len(lows) - 1):
            if lows[i+1][1] > lows[i][1]:
                hl_count += 1
        
        for i in range(len(highs) - 3, len(highs) - 1):
            if highs[i+1][1] < highs[i][1]:
                lh_count += 1
        
        for i in range(len(lows) - 3, len(lows) - 1):
            if lows[i+1][1] < lows[i][1]:
                ll_count += 1
        
        # Bullish: HH and HL (at least 2 of each pattern)
        if hh_count >= 1 and hl_count >= 1:
            trend = "Bullish"
            structure = "Higher highs / higher lows (bullish impulse)"
            score += 20
        # Bearish: LH and LL (at least 2 of each pattern)
        elif lh_count >= 1 and ll_count >= 1:
            trend = "Bearish"
            structure = "Lower highs / lower lows (bearish impulse)"
            score -= 20

    # IMPROVEMENT: Volume-confirmed Breakout of Structure (BOS)
    bos = "None"
    choch = "None"
    
    if highs and last_close > highs[-1][1]:
        # Bullish BOS confirmed by volume
        if last_vol > vol_avg * 1.1:
            bos = "Bullish BOS (strong volume)"
            score += 16
        else:
            bos = "Bullish BOS (weak volume)"
            score += 8

    elif lows and last_close < lows[-1][1]:
        # Bearish BOS confirmed by volume
        if last_vol > vol_avg * 1.1:
            bos = "Bearish BOS (strong volume)"
            score -= 16
        else:
            bos = "Bearish BOS (weak volume)"
            score -= 8

    # IMPROVEMENT: Better CHOCH (Change of Character) detection
    if len(highs) >= 2 and len(lows) >= 2:
        # Bullish CHOCH risk: bearish trend breaks to bullish
        if trend == "Bearish" and highs and last_close > highs[-1][1]:
            if last_vol > vol_avg:
                choch = "Bullish CHOCH confirmed"
                score += 14
            else:
                choch = "Bullish CHOCH risk"
                score += 7
        
        # Bearish CHOCH risk: bullish trend breaks to bearish
        elif trend == "Bullish" and lows and last_close < lows[-1][1]:
            if last_vol > vol_avg:
                choch = "Bearish CHOCH confirmed"
                score -= 14
            else:
                choch = "Bearish CHOCH risk"
                score -= 7

    return StructureSignal(trend, structure, bos, choch, score)
