from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import pandas as pd

from config import CONFIG
from indicators import add_indicators, slope
from structure_analysis import analyze_structure


@dataclass
class TrendTargetSignal:
    side: str = "NO TRADE"
    score: int = 0
    current_price: float = 0.0
    entry_zone: Optional[Tuple[float, float]] = None
    stop_loss: Optional[float] = None
    take_profits: List[float] = field(default_factory=list)
    reward_risk: Optional[float] = None
    notes: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def _fmt_zone(a, b):
    return (min(a, b), max(a, b))


def _liquidity_targets(df15: pd.DataFrame, df5: pd.DataFrame, side: str, current: float, atr: float):
    look15 = df15.tail(60)
    look5 = df5.tail(80) if df5 is not None and len(df5) > 20 else look15

    if side == "LONG":
        highs = sorted(set([float(x) for x in list(look15["high"].nlargest(6)) + list(look5["high"].nlargest(6))]))
        targets = [x for x in highs if x > current]
        if len(targets) < 3:
            targets += [current + atr * 1.2, current + atr * 2.0, current + atr * 3.0]
        return sorted(targets)[:3]

    if side == "SHORT":
        lows = sorted(set([float(x) for x in list(look15["low"].nsmallest(6)) + list(look5["low"].nsmallest(6))]), reverse=True)
        targets = [x for x in lows if x < current]
        if len(targets) < 3:
            targets += [current - atr * 1.2, current - atr * 2.0, current - atr * 3.0]
        return sorted(targets, reverse=True)[:3]

    return []


def _reward_risk(side: str, entry_mid: float, stop: float, tp1: float):
    risk = abs(entry_mid - stop)
    reward = abs(tp1 - entry_mid)
    if risk <= 0:
        return None
    return reward / risk


def _get_volatility_level(atr: float, current: float) -> str:
    """Determine volatility regime based on ATR."""
    atr_pct = (atr / current) * 100
    if atr_pct > 2.0:
        return "high"
    elif atr_pct > 0.8:
        return "normal"
    else:
        return "low"


def _calculate_ema_confluence(last: pd.Series) -> int:
    """
    IMPROVEMENT: Better EMA weighting instead of binary stack.
    Gives partial credit for 2 out of 3 alignment.
    """
    score = 0
    ema9, ema21, ema50 = float(last["ema9"]), float(last["ema21"]), float(last["ema50"])
    
    # Bullish alignment
    if ema9 > ema21:
        score += 8
    if ema21 > ema50:
        score += 8
    if ema9 > ema50:
        score += 6
    
    # Bearish alignment
    if ema9 < ema21:
        score -= 8
    if ema21 < ema50:
        score -= 8
    if ema9 < ema50:
        score -= 6
    
    return score


def _calculate_momentum_score(last: pd.Series) -> Tuple[int, str]:
    """
    IMPROVEMENT: Better RSI and Stochastic weighting with graduated zones.
    """
    score = 0
    notes = []
    
    rsi = float(last["rsi"])
    k = float(last["stoch_k"])
    d = float(last["stoch_d"])
    
    # RSI graduated zones
    if rsi > 70:
        score += 6
        notes.append("RSI overbought (70+) - watch pullback")
    elif rsi > 55:
        score += 5
        notes.append("RSI bullish (55-70)")
    elif rsi > 50:
        score += 2
        notes.append("RSI slightly bullish (50-55)")
    elif rsi > 45:
        score -= 2
        notes.append("RSI slightly bearish (45-50)")
    elif rsi > 30:
        score -= 5
        notes.append("RSI bearish (30-45)")
    else:
        score -= 6
        notes.append("RSI oversold (<30) - watch bounce")
    
    # Stochastic with divergence consideration
    if k > d and k < 80:
        if k < 50:
            score += 8  # K above D but still in lower half = strong signal
            notes.append("Stoch bullish divergence (K>D, K<50)")
        elif k < 65:
            score += 5
            notes.append("Stoch rising bullish")
        else:
            score += 2
            notes.append("Stoch rising but approaching overbought")
    elif k < d and k > 20:
        if k > 50:
            score -= 8  # K below D but still in upper half = strong signal
            notes.append("Stoch bearish divergence (K<D, K>50)")
        elif k > 35:
            score -= 5
            notes.append("Stoch falling bearish")
        else:
            score -= 2
            notes.append("Stoch falling but approaching oversold")
    
    return score, " | ".join(notes)


def _calculate_volume_score(last: pd.Series) -> Tuple[int, str]:
    """
    IMPROVEMENT: Better volume confirmation with graduated thresholds.
    """
    score = 0
    note = ""
    
    vol_ratio = float(last["volume"]) / float(last["vol_ma20"])
    
    if vol_ratio > 1.5:
        score = 12
        note = "Strong volume confirmation (>150% avg)"
    elif vol_ratio > 1.2:
        score = 6
        note = "Above-average volume (120-150%)"
    elif vol_ratio > 0.9:
        score = 2
        note = "Normal volume (90-120%)"
    else:
        score = -8
        note = "⚠️ Weak volume (<90%) - potential rejection"
    
    return score, note


def validate_math(signal: TrendTargetSignal) -> TrendTargetSignal:
    if signal.side not in {"LONG", "SHORT"}:
        return signal

    if not signal.entry_zone or signal.stop_loss is None or not signal.take_profits:
        signal.side = "NO TRADE"
        signal.warnings.append("Rejected: missing entry, stop, or TP.")
        return signal

    entry_mid = sum(signal.entry_zone) / 2
    tp1 = signal.take_profits[0]

    if signal.side == "LONG":
        if CONFIG.reject_long_if_tp_below_entry and any(tp <= entry_mid for tp in signal.take_profits):
            signal.side = "NO TRADE"
            signal.warnings.append("Rejected: LONG TP is not above entry.")
        if signal.stop_loss >= entry_mid:
            signal.side = "NO TRADE"
            signal.warnings.append("Rejected: LONG stop must be below entry.")

    if signal.side == "SHORT":
        if CONFIG.reject_short_if_tp_above_entry and any(tp >= entry_mid for tp in signal.take_profits):
            signal.side = "NO TRADE"
            signal.warnings.append("Rejected: SHORT TP is not below entry.")
        if signal.stop_loss <= entry_mid:
            signal.side = "NO TRADE"
            signal.warnings.append("Rejected: SHORT stop must be above entry.")

    signal.reward_risk = _reward_risk(signal.side, entry_mid, signal.stop_loss, tp1) if signal.side in {"LONG", "SHORT"} else None

    # IMPROVEMENT: Graduated quality gates instead of hard rejection
    if signal.side in {"LONG", "SHORT"} and signal.reward_risk:
        if signal.reward_risk < CONFIG.min_reward_risk_for_active_setup:
            signal.warnings.append(f"Reward/risk weaker than ideal: {signal.reward_risk:.2f}R (min {CONFIG.min_reward_risk_for_active_setup}R)")
            # Don't auto-reject, let probability and confluence decide
            if signal.reward_risk < 1.15:
                signal.side = "NO TRADE"
                signal.warnings.append("Rejected: Reward/risk critically low (<1.15R)")

    return signal


def analyze_15m_trend_targets(df15: pd.DataFrame, df5: pd.DataFrame) -> TrendTargetSignal:
    df15 = add_indicators(df15)
    df5 = add_indicators(df5) if df5 is not None and len(df5) > 50 else df15

    last = df15.iloc[-1]
    current = float(last["close"])
    
    # IMPROVEMENT: Better ATR default
    atr = float(last["atr"]) if float(last["atr"]) > 0 else current * 0.015
    volatility = _get_volatility_level(atr, current)

    structure = analyze_structure(df15)
    trend_slope = slope(df15["close"], 10)

    score = 0
    notes = []

    # IMPROVEMENT: Use graduated EMA weighting
    ema_score = _calculate_ema_confluence(last)
    score += ema_score
    if ema_score > 10:
        notes.append("15m strong bullish EMA stack")
    elif ema_score > 0:
        notes.append("15m partial bullish EMA alignment")
    elif ema_score < -10:
        notes.append("15m strong bearish EMA stack")
    elif ema_score < 0:
        notes.append("15m partial bearish EMA alignment")

    # Trend slope
    if trend_slope > 0.18:
        score += 12
        notes.append("15m trend slope rising")
    elif trend_slope < -0.18:
        score -= 12
        notes.append("15m trend slope falling")

    # Structure
    score += structure.score
    notes.append(f"15m structure: {structure.structure}")
    if structure.bos != "None":
        notes.append(structure.bos)
    if structure.choch != "None":
        notes.append(structure.choch)

    # IMPROVEMENT: Better momentum scoring
    momentum_score, momentum_note = _calculate_momentum_score(last)
    score += momentum_score
    notes.append(f"15m momentum: {momentum_note}")

    # IMPROVEMENT: Better volume scoring
    volume_score, volume_note = _calculate_volume_score(last)
    score += volume_score
    notes.append(volume_note)

    # Determine side based on improved scoring
    side = "NO TRADE"
    if score >= CONFIG.early_15m_min_score:
        side = "LONG"
    elif score <= -CONFIG.early_15m_min_score:
        side = "SHORT"

    sig = TrendTargetSignal(side=side, score=score, current_price=current, notes=notes)

    if side == "LONG":
        # IMPROVEMENT: Better entry zone calculation with structure context
        recent_low_20 = float(df15["low"].tail(20).min())
        recent_low_10 = float(df15["low"].tail(10).min())
        
        # Entry zone between recent support and current
        pullback_high = current - (atr * 0.15)
        pullback_low = max(recent_low_10, current - (atr * 0.65))
        sig.entry_zone = _fmt_zone(pullback_low, pullback_high)
        
        # IMPROVEMENT: Volatility-aware stop loss
        sl_buffer = atr * 0.35 if volatility == "low" else atr * 0.55
        sig.stop_loss = min(recent_low_20, sig.entry_zone[0] - sl_buffer)
        
        sig.take_profits = _liquidity_targets(df15, df5, "LONG", current, atr)

    elif side == "SHORT":
        # IMPROVEMENT: Better entry zone for shorts
        recent_high_20 = float(df15["high"].tail(20).max())
        recent_high_10 = float(df15["high"].tail(10).max())
        
        # Entry zone between current and recent resistance
        pullback_low = current + (atr * 0.15)
        pullback_high = min(recent_high_10, current + (atr * 0.65))
        sig.entry_zone = _fmt_zone(pullback_low, pullback_high)
        
        # IMPROVEMENT: Volatility-aware stop loss
        sl_buffer = atr * 0.35 if volatility == "low" else atr * 0.55
        sig.stop_loss = max(recent_high_20, sig.entry_zone[1] + sl_buffer)
        
        sig.take_profits = _liquidity_targets(df15, df5, "SHORT", current, atr)

    sig = validate_math(sig)

    if side in {"LONG", "SHORT"} and sig.side == "NO TRADE":
        sig.notes.append("Trend existed but TP/SL validation rejected active setup.")

    # 5m exit / TP warning
    last5 = df5.iloc[-1]
    if side == "LONG" and float(last5["stoch_k"]) > 85:
        sig.warnings.append("5m overbought (K>85): consider quicker partial TP if already in long.")
    if side == "SHORT" and float(last5["stoch_k"]) < 15:
        sig.warnings.append("5m oversold (K<15): consider quicker partial TP if already in short.")

    return sig
