# Crypto AI Pro 15m Bot - Code Review & Accuracy Improvements

## Executive Summary
The bot runs successfully but has several logic issues that reduce accuracy. This document outlines critical problems and professional-grade fixes.

---

## 🔴 CRITICAL ACCURACY ISSUES

### 1. **EMA Stack Logic Too Restrictive**
**File:** `trend_target_analysis.py` (lines 102-103)
**Problem:** 
```python
ema_bull = last["ema9"] > last["ema21"] > last["ema50"]
ema_bear = last["ema9"] < last["ema21"] < last["ema50"]
```
- Requires PERFECT stacking - misses valid trends
- Doesn't give partial credit for alignment  
- Too binary; ignores when 2 out of 3 are aligned

**Impact:** False negatives on valid setups
**Fix:** Use weighted scoring:
```python
bullish_alignment = 0
if last["ema9"] > last["ema21"]:
    bullish_alignment += 8
if last["ema21"] > last["ema50"]:
    bullish_alignment += 8  
if last["ema9"] > last["ema50"]:
    bullish_alignment += 6
    
score += bullish_alignment if bullish_alignment > 0 else -bullish_alignment
```

---

### 2. **Stochastic Signal Logic Backward**
**File:** `trend_target_analysis.py` (lines 140-145)
**Problem:**
```python
if k > d and k < 85:
    score += 6  # Rising stochastic
    notes.append("15m stochastic rising")
elif k < d and k > 15:
    score -= 6  # Falling stochastic
```
- This only rewards when K *just* crossed above D
- Doesn't account for divergence (strong bullish signal)
- Treats "K crossing above D near bottom" same as "K already above D"

**Fix:** Add divergence detection:
```python
# Check for bullish divergence: price lower, stoch higher
# Check for bearish divergence: price higher, stoch lower
if k > d:
    if k < 50:  # Stoch below midpoint = more bullish
        score += 8
    elif k < 80:
        score += 4
elif k < d:
    if k > 50:  # Stoch above midpoint = more bearish
        score -= 8
    elif k > 20:
        score -= 4
```

---

### 3. **RSI Zones Are Too Loose**
**File:** `trend_target_analysis.py` (lines 133-138)
**Problem:**
```python
if rsi > 55:  # Very loose threshold
    score += 8
elif rsi < 45:
    score -= 8
```
- RSI 51 gets same weight as RSI 75
- Doesn't distinguish between "slightly bullish" and "strongly bullish"
- Missing overbought/oversold detection

**Fix:** Use graduated zones:
```python
if rsi > 70:
    if ema_bull:  # Confirmation
        score += 10
    else:
        score += 4  # Potential reversal signal
        notes.append("RSI overbought - watch for pullback")
elif rsi > 55:
    score += 5
elif rsi < 30:
    if ema_bear:
        score -= 10
    else:
        score -= 4
        notes.append("RSI oversold - watch for bounce")
elif rsi < 45:
    score -= 5
```

---

### 4. **Probability Calculation Flawed**
**File:** `bias_engine.py` (lines 117-122)
**Problem:**
```python
if side == "LONG":
    probability = min(96, max(50, 55 + trend15.score + htf_bonus))
elif side == "SHORT":
    probability = min(96, max(50, 55 + abs(trend15.score) + htf_bonus))
else:
    probability = min(65, max(40, 50 + abs(trend15.score) // 4))
```
- Base probability of 55% is arbitrary for LONG/SHORT
- Uses LINEAR math for non-linear confidence
- Doesn't normalize score vs probability properly
- HTF bonus (max 9) barely moves needle vs trend score (can be 50+)

**Fix:** Use sigmoid-like normalization:
```python
def _calculate_probability(side, trend_score, htf_bonus, config):
    if side == "NO TRADE":
        return 45
    
    # Trend score ranges -60 to +60, normalize to 0-100
    base = 50 + (trend_score / 60) * 30  # 20-80 range
    
    # HTF support (better weighting)
    htf_factor = 1.0 + (htf_bonus / 15) * 0.3  # 1.0 to 1.3x
    
    prob = min(base * htf_factor, 95)
    return max(45, int(prob))
```

---

### 5. **Stop Loss Placement Is Arbitrary**
**File:** `trend_target_analysis.py` (lines 162-166, 170-174)
**Problem:**
```python
if side == "LONG":
    pullback_high = current - atr * 0.15
    pullback_low = current - atr * 0.65
    recent_low = float(df15["low"].tail(20).min())
    sig.stop_loss = min(recent_low, sig.entry_zone[0] - atr * 0.35)
```
- Fixed ATR multipliers (0.35 for safety buffer) don't adapt to volatility
- "Recent low from tail(20)" = arbitrary 300 minutes for 15m - misses major support
- Doesn't consider structure (pivot lows, liquidity levels)

**Fix:**
```python
def _calculate_stop_loss(df, current, side, atr, volatility_level):
    lookback = 40 if volatility_level == "high" else 20
    
    if side == "LONG":
        structure_low = float(df["low"].tail(lookback).min())
        # Add structure buffer based on volatility
        buffer = atr * 0.25 if volatility_level == "low" else atr * 0.45
        return min(structure_low, current - buffer)
    else:
        structure_high = float(df["high"].tail(lookback).max())
        buffer = atr * 0.25 if volatility_level == "low" else atr * 0.45
        return max(structure_high, current + buffer)
```

---

### 6. **Volume Confirmation Too Weak**
**File:** `trend_target_analysis.py` (lines 147-151)
**Problem:**
```python
volume_ok = float(last["volume"]) > float(last["vol_ma20"]) * 0.9  # 90% of average!
if volume_ok:
    notes.append("Volume acceptable")
else:
    notes.append("Volume below ideal confirmation")
```
- 90% threshold is almost never breached
- Doesn't weight LOW volume as rejection signal
- No volume spike detection for entry confirmation

**Fix:**
```python
vol_ratio = last["volume"] / last["vol_ma20"]
volume_score = 0

if vol_ratio > 1.5:
    volume_score = 12
    notes.append("Strong volume confirmation")
elif vol_ratio > 1.2:
    volume_score = 6
    notes.append("Above-average volume")
elif vol_ratio > 0.8:
    volume_score = 2
    notes.append("Normal volume")
else:
    volume_score = -8
    notes.append("WARNING: Weak volume - potential rejection")
    
score += volume_score
```

---

### 7. **Entry Zone Calculation Lacks Structure Context**
**File:** `trend_target_analysis.py` (lines 162-164, 170-172)
**Problem:**
```python
pullback_high = current - atr * 0.15
pullback_low = current - atr * 0.65
sig.entry_zone = _fmt_zone(pullback_low, pullback_high)
```
- Ignores actual pullback support levels
- Fixed to price without considering structure
- Doesn't validate entry zone near support

**Fix:** Use actual structure levels:
```python
def _find_entry_zone(df, current, side, atr, structure):
    if side == "LONG":
        # Find pullback support within last 10 candles
        support_level = float(df["low"].tail(10).min())
        resistance_above_support = float(df["high"].tail(10).max())
        
        # Entry zone between support and current price
        upper = current - (atr * 0.15)
        lower = max(support_level, current - (atr * 0.65))
        
        return (lower, upper)
    # ... similar for SHORT
```

---

### 8. **No Confluence Weighting**
**File:** `bias_engine.py`, `trend_target_analysis.py`
**Problem:** 
All signals get equal weight. A trend confirmed by:
- EMA stack + RSI + Stochastic + Volume = same probability as just EMA stack

**Fix:** Implement confluence scoring:
```python
confluence_signals = 0
if ema_bull:
    confluence_signals += 1
if rsi > 55:
    confluence_signals += 1
if k > d and k < 80:
    confluence_signals += 1
if volume_strong:
    confluence_signals += 1
if structure_bullish:
    confluence_signals += 1

# Bonus for confluence
confluence_bonus = (confluence_signals - 1) * 5 if confluence_signals > 0 else 0
score += confluence_bonus
notes.append(f"Confluence: {confluence_signals}/5 signals aligned")
```

---

### 9. **Reward/Risk Validation Too Strict for Active Setup**
**File:** `trend_target_analysis.py` (lines 86-88), config
**Problem:**
```python
if signal.side in {"LONG", "SHORT"} and (signal.reward_risk is None or signal.reward_risk < CONFIG.min_reward_risk_for_active_setup):
    signal.warnings.append(...)
    signal.side = "NO TRADE"
```
With `min_reward_risk_for_active_setup: float = 1.25` in config, legitimate setups get rejected.

**Fix:** Graduated quality gates:
```python
if side == "LONG" or side == "SHORT":
    if reward_risk >= 1.8:
        quality = "High"
        can_use_leverage = True
    elif reward_risk >= 1.5:
        quality = "Moderate-High"
        can_use_leverage = True
    elif reward_risk >= 1.25:
        quality = "Moderate"
        can_use_leverage = False  # Reduce leverage, don't reject
    elif reward_risk >= 1.15:
        quality = "Low"
        status = "EARLY WATCH ONLY"
    else:
        quality = "Very Low"
        side = "NO TRADE"  # Only reject if truly terrible
```

---

### 10. **Structure Analysis Uses Simple Pivot Logic**
**File:** `structure_analysis.py` (lines 14-23)
**Problem:**
```python
def _pivot_highs_lows(df: pd.DataFrame, lookback: int = 3):
    for i in range(lookback, len(df) - lookback):
        h = df["high"].iloc[i]
        l = df["low"].iloc[i]
        if h == df["high"].iloc[i-lookback:i+lookback+1].max():  # Equality check!
```
- Uses `==` for equality on floats (dangerous)
- Only 5 pivots tracked; misses important structure
- Doesn't distinguish swing highs vs major resistance
- No volume confirmation on pivots

**Fix:**
```python
def _find_significant_levels(df, lookback=3):
    pivots = []
    for i in range(lookback, len(df) - lookback):
        high_window = df["high"].iloc[i-lookback:i+lookback+1]
        low_window = df["low"].iloc[i-lookback:i+lookback+1]
        
        current_high = df["high"].iloc[i]
        current_low = df["low"].iloc[i]
        current_vol = df["volume"].iloc[i]
        
        # Use >= for floats, add volume context
        if current_high >= high_window.max() * 0.999 and current_vol > df["volume"].mean():
            pivots.append(("high", i, float(current_high)))
        if current_low <= low_window.min() * 1.001 and current_vol > df["volume"].mean():
            pivots.append(("low", i, float(current_low)))
    
    return pivots[-10:]  # Return last 10, not 5
```

---

### 11. **Missing Trend Confirmation on Lower Timeframes**
**File:** `bias_engine.py` (line 103)
**Problem:**
```python
trend15 = analyze_15m_trend_targets(market_data["15m"], market_data["5m"])
```
- 5m data is passed but only used for liquidity targets
- No actual 5m trend confirmation for entry timing
- 5m overbought/oversold warning is too simplistic

**Fix:** Add 5m confirmation scoring:
```python
def _get_5m_confirmation(df5, trend_direction):
    df5 = add_indicators(df5)
    last5 = df5.iloc[-1]
    
    confirmation = 0
    if trend_direction == "LONG":
        if last5["ema9"] > last5["ema21"]:
            confirmation += 8
        if last5["rsi"] > 50 and last5["rsi"] < 70:
            confirmation += 5
        if last5["stoch_k"] > last5["stoch_d"] and last5["stoch_k"] < 80:
            confirmation += 5
    # Similar for SHORT
    
    return confirmation
```

---

### 12. **Alert Deduplication Too Simplistic**
**File:** `live_update_engine.py` (lines 37-39)
**Problem:**
```python
key = f"{best.symbol}-{best.bias}-{best.probability}"
if key == self.last_alert_key:
    return
```
- Same symbol/bias with probability 75% then 76% triggers new alert
- No time window check (could spam alerts)
- Doesn't track which setups already generated alerts

**Fix:**
```python
class AlertTracker:
    def __init__(self):
        self.alerts = {}  # symbol-bias -> (probability, timestamp)
    
    def should_alert(self, symbol, bias, probability):
        key = f"{symbol}-{bias}"
        now = time.time()
        
        if key not in self.alerts:
            self.alerts[key] = (probability, now)
            return True
        
        last_prob, last_time = self.alerts[key]
        
        # Only alert if 5+ minutes passed AND probability changed by 3%+
        if (now - last_time > 300) and (abs(probability - last_prob) >= 3):
            self.alerts[key] = (probability, now)
            return True
        
        return False
```

---

## 📊 CONFIGURATION IMPROVEMENTS

### Current Config Issues:

**1. Unbalanced Probability Thresholds**
```python
min_probability_for_alert: int = 68  # Too low for live trading
min_probability_for_active_setup: int = 72  # Only 4% difference
min_probability_for_high_leverage: int = 82  # Too strict
```

**Better Config:**
```python
min_probability_for_alert: int = 72  # Base alert threshold
min_probability_for_active_setup: int = 78  # Actual trade setup
min_probability_for_high_leverage: int = 85  # Conservative
```

**2. Weak Risk Management**
```python
risk_per_trade_percent: float = 1.0  # No position sizing
max_daily_loss_percent: float = 5.0  # Not enforced
```

**Better:**
```python
risk_per_trade_percent: float = 0.5  # Smaller initial risk
max_daily_loss_percent: float = 3.0  # Tighter stop
position_sizing_method: str = "kelly"  # Not just fixed percent
```

---

## 🔧 QUICK WINS (Easy Fixes for Immediate Improvement)

### 1. Fix Volume Threshold (1 minute)
**File:** `trend_target_analysis.py` line 147
```python
# BEFORE
volume_ok = float(last["volume"]) > float(last["vol_ma20"]) * 0.9

# AFTER  
volume_ok = float(last["volume"]) > float(last["vol_ma20"]) * 1.1
```

### 2. Fix Stochastic Logic (2 minutes)
**File:** `indicators.py` - add smoothing:
```python
df["stoch_d"] = df["stoch_k"].rolling(3).mean()
# ADD THIS:
df["stoch_d_smooth"] = df["stoch_d"].ewm(span=3, adjust=False).mean()
```

### 3. Improve Trend Score Clipping (2 minutes)
**File:** `bias_engine.py` lines 117-122
```python
# Add asymmetric probability
if side == "LONG":
    probability = min(94, max(52, 55 + trend15.score + htf_bonus))
elif side == "SHORT":
    probability = min(94, max(52, 55 + abs(trend15.score) + htf_bonus))
```

### 4. Better ATR Default (1 minute)
**File:** `trend_target_analysis.py` line 99
```python
# BEFORE
atr = float(last["atr"]) if float(last["atr"]) > 0 else current * 0.003

# AFTER (more realistic ATR)
atr = float(last["atr"]) if float(last["atr"]) > 0 else current * 0.015
```

### 5. Add BOS/CHOCH Confirmation (3 minutes)
**File:** `structure_analysis.py` lines 52-57
```python
# ADD validation that BOS is on volume
if highs and last_close > highs[-1][1]:
    bos_volume = float(df["volume"].iloc[-1])
    vol_avg = float(df["volume"].rolling(20).mean().iloc[-1])
    if bos_volume > vol_avg * 1.2:
        bos = "Bullish BOS (confirmed)"
        score += 14
    else:
        bos = "Bullish BOS (weak volume)"
        score += 7
```

---

## 🚀 ADVANCED IMPROVEMENTS (Major Refactor)

### 1. Implement Liquidity Profile Analysis
- Track buy/sell walls
- Weight targets by volume nodes
- Avoid low-volume targets

### 2. Add Market Microstructure
- Monitor bid-ask spread
- Track large order flow
- Detect stop hunts

### 3. Multi-Timeframe Confluence Engine
- Weight confluence by importance
- Create probabilistic models
- Use Bayesian updates

### 4. Volatility Regime Detection
- Calculate Historical Volatility
- Adjust all parameters dynamically
- Different strategies for high/low vol

### 5. Backtesting Framework
- Validate accuracy vs historical
- Parameter optimization
- Drawdown analysis

---

## 📋 IMPLEMENTATION PRIORITY

**Phase 1 (Immediate - 1 hour):**
- Fix volume threshold
- Improve probability calculation
- Better EMA stack logic

**Phase 2 (This week - 4 hours):**
- Rewrite stop loss logic with structure
- Add confluence weighting
- Improve entry zone calculation

**Phase 3 (Next week - 8 hours):**
- Gradient risk/quality gates
- Better 5m confirmation
- Structure analysis improvements

**Phase 4 (Long-term):**
- Advanced volatility regime detection
- Liquidity profile analysis
- Bayesian probability updates

---

## ✅ VALIDATION CHECKLIST

After implementing fixes:
- [ ] Test on last 100 candles (2500m = ~1.7 days)
- [ ] Compare probability accuracy vs entry prices
- [ ] Check reward/risk math validates on all setups
- [ ] Verify no false positives on choppy markets
- [ ] Validate alerts only fire on new confluences
- [ ] Test with extreme volatility (>200% ATR moves)
- [ ] Verify stop loss placement never inverted
- [ ] Check entry zones contain structure support
- [ ] Validate TP targets are reachable
- [ ] Monitor false alert rate (aim <20%)

