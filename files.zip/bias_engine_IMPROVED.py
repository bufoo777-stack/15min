from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import pandas as pd
import math

from config import CONFIG
from indicators import add_indicators
from candle_analysis import analyze_last_candle
from structure_analysis import analyze_structure
from trend_target_analysis import analyze_15m_trend_targets


@dataclass
class TimeframeAnalysis:
    timeframe: str
    trend: str
    candle: str
    momentum: str
    score: int


@dataclass
class Decision:
    symbol: str
    bias: str
    probability: int
    risk: str
    quality: str
    suggested_leverage: int
    status: str
    current_price: float
    entry_zone: Optional[Tuple[float, float]] = None
    stop_loss: Optional[float] = None
    take_profits: List[float] = field(default_factory=list)
    reward_risk: Optional[float] = None
    timeframe_notes: List[str] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def analyze_timeframe(timeframe: str, df: pd.DataFrame) -> TimeframeAnalysis:
    df = add_indicators(df)
    candle = analyze_last_candle(df)
    structure = analyze_structure(df)
    last = df.iloc[-1]

    score = candle.score + structure.score
    rsi = float(last["rsi"])
    k = float(last["stoch_k"])
    d = float(last["stoch_d"])

    momentum = "Neutral momentum"
    if rsi > 55 and k > d:
        momentum = "Bullish momentum"
        score += 10
    elif rsi < 45 and k < d:
        momentum = "Bearish momentum"
        score -= 10

    if float(last["volume"]) > float(last["vol_ma20"]) * 1.15:
        score += 5 if score >= 0 else -5

    return TimeframeAnalysis(
        timeframe=timeframe,
        trend=structure.trend,
        candle=candle.label,
        momentum=momentum,
        score=int(score),
    )


def _quality(probability: int, rr: Optional[float]) -> str:
    """
    IMPROVEMENT: Graduated quality gates based on probability AND reward/risk.
    """
    if probability >= 85 and rr and rr >= CONFIG.preferred_reward_risk:
        return "High"
    if probability >= 78 and rr and rr >= 1.5:
        return "High"
    if probability >= 72 and rr and rr >= 1.25:
        return "Moderate-High"
    if probability >= 68 and rr and rr >= 1.15:
        return "Moderate"
    if probability >= 65:
        return "Fair"
    return "Low"


def _risk(probability: int, rr: Optional[float]) -> str:
    """
    IMPROVEMENT: Risk assessment tied to both probability and reward/risk.
    """
    if probability >= 85 and rr and rr >= 1.8:
        return "Moderate"
    if probability >= 78 and rr and rr >= 1.5:
        return "Moderate"
    if probability >= 72 and rr and rr >= 1.25:
        return "Moderate-High"
    if probability >= 68 and rr and rr >= 1.15:
        return "Moderate-High"
    if probability >= 62:
        return "High"
    return "Very High"


def _leverage(probability: int, quality: str, risk: str) -> int:
    """
    IMPROVEMENT: Better leverage allocation based on confluence of factors.
    """
    if quality == "High" and probability >= CONFIG.min_probability_for_high_leverage and risk == "Moderate":
        return min(CONFIG.max_leverage, 20)
    elif quality == "High" and probability >= 78:
        return min(CONFIG.default_leverage, 15)
    elif quality == "Moderate-High" and probability >= 72:
        return min(CONFIG.default_leverage, 10)
    elif quality == "Moderate" and probability >= 68:
        return min(CONFIG.default_leverage, 5)
    elif quality == "Fair" and probability >= 62:
        return 2
    return 0


def _normalize_probability(side: str, trend_score: int, htf_bonus: int) -> int:
    """
    IMPROVEMENT: Better probability normalization using sigmoid-like function.
    Trend score ranges -60 to +60, normalize to 0-100 range.
    """
    if side == "NO TRADE":
        return 45
    
    # Normalize trend score to -1 to +1 range
    norm_score = max(-1, min(1, trend_score / 60.0))
    
    # Base probability: 50% + trend * 30% = 50-80% range
    base_prob = 50 + (norm_score * 30)
    
    # HTF support multiplier (max 1.3x)
    htf_factor = 1.0 + (max(0, htf_bonus) / 18.0) * 0.25
    
    # Apply HTF factor
    prob = base_prob * htf_factor
    
    # Cap and floor
    prob = min(94, max(48, prob))
    
    return int(prob)


def decide_symbol(symbol: str, market_data: Dict[str, pd.DataFrame]) -> Decision:
    """
    IMPROVEMENT: Better confluence weighting and quality gates.
    """
    if "15m" not in market_data or "5m" not in market_data:
        return Decision(symbol, "NO TRADE", 0, "High", "Low", 0, "Missing 15m/5m data.", 0.0)

    tf_analyses = []
    for tf, df in market_data.items():
        tf_analyses.append(analyze_timeframe(tf, df))

    trend15 = analyze_15m_trend_targets(market_data["15m"], market_data["5m"])
    side = trend15.side

    # IMPROVEMENT: Better HTF support scoring
    htf_bonus = 0
    htf_count = 0
    for tfa in tf_analyses:
        if tfa.timeframe in {"2h", "4h", "1d"}:
            if side == "LONG" and tfa.score > 5:
                htf_bonus += 4
                htf_count += 1
            elif side == "LONG" and tfa.score > 0:
                htf_bonus += 1
                htf_count += 1
            elif side == "SHORT" and tfa.score < -5:
                htf_bonus += 4
                htf_count += 1
            elif side == "SHORT" and tfa.score < 0:
                htf_bonus += 1
                htf_count += 1
            elif side in {"LONG", "SHORT"}:
                htf_bonus -= 3  # Counter-evidence penalty

    # IMPROVEMENT: Better probability calculation
    probability = _normalize_probability(side, trend15.score, htf_bonus)

    quality = _quality(probability, trend15.reward_risk)
    risk = _risk(probability, trend15.reward_risk)
    lev = _leverage(probability, quality, risk)

    reasons = list(trend15.notes)
    if htf_count > 0:
        reasons.append(f"HTF support: {htf_count} timeframes aligned")
    
    warnings = list(trend15.warnings)

    # IMPROVEMENT: Graduated quality gates instead of binary logic
    if side == "LONG" or side == "SHORT":
        if probability >= CONFIG.min_probability_for_active_setup and quality in {"High", "Moderate-High"}:
            status = f"{side} scalp setup active; use 5m confirmation, partial TPs, and hard invalidation."
            bias = side
        elif probability >= 75 and quality in {"Moderate", "Fair"}:
            status = f"POTENTIAL {side} SCALP — monitor for confirmation, reduced leverage only."
            bias = side
            lev = max(0, min(lev or 3, 5))
        elif probability >= CONFIG.min_probability_for_alert:
            status = f"EARLY 15M {side} WATCH — alert early, do not full-size without 5m execution confirmation."
            bias = side
            lev = min(lev or 2, 3)
        else:
            status = "NO HIGH-QUALITY SETUP DETECTED."
            bias = "NO TRADE"
            lev = 0
    else:
        status = "NO HIGH-QUALITY SETUP DETECTED."
        bias = "NO TRADE"
        lev = 0

    # Never output active trade if TP/SL math failed.
    if side == "NO TRADE":
        bias = "NO TRADE"
        lev = 0
        status = "NO TRADE — TP/SL or trend validation rejected the setup."

    timeframe_notes = [
        f"{x.timeframe}: {x.trend}; {x.candle}; {x.momentum}; score {x.score}"
        for x in sorted(tf_analyses, key=lambda x: ["5m","15m","2h","4h","1d"].index(x.timeframe) if x.timeframe in ["5m","15m","2h","4h","1d"] else 99)
    ]

    return Decision(
        symbol=symbol,
        bias=bias,
        probability=int(probability),
        risk=risk,
        quality=quality,
        suggested_leverage=lev,
        status=status,
        current_price=trend15.current_price,
        entry_zone=trend15.entry_zone,
        stop_loss=trend15.stop_loss,
        take_profits=trend15.take_profits,
        reward_risk=trend15.reward_risk,
        timeframe_notes=timeframe_notes,
        reasons=reasons,
        warnings=warnings,
    )
